document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('key').append(localStorage.getItem('keyST'));
    StocksAPI.TIME_SERIES_INTRADAY(localStorage.getItem('keyST'))
    .then((result) => {
        document.getElementById('key').append(result);
    }).catch((err) => {
        console.error(err);
    });
});