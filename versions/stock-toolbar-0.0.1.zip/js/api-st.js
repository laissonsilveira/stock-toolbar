//eslint-disable-next-line
class StocksAPI {

	static init() {
		if (!localStorage.getItem('tokenST') || !localStorage.getItem('keyST')) {
			fetch('https://www.alphavantage.co/support/#api-key');
		}
		else {
			!localStorage.getItem('keyST') && StocksAPI.getAPIkey();
		}
	}

	static addHandlers() {
		chrome.webRequest.onBeforeSendHeaders.addListener(
			function (details) {
				const token = localStorage.getItem('tokenST');
				StocksAPI.changeHeader(details, 'Referer', 'https://www.alphavantage.co/support/');
				StocksAPI.changeHeader(details, 'X-CSRFToken', token);
				StocksAPI.changeHeader(details, 'Cookie', `csrftoken=${token}`);
				StocksAPI.changeHeader(details, 'Origin', 'https://www.alphavantage.co');
				return { requestHeaders: details.requestHeaders };
			},
			{ urls: ['https://www.alphavantage.co/create_post/'] }, ['blocking', 'requestHeaders', 'extraHeaders']
		);

		chrome.webRequest.onHeadersReceived.addListener(
			function (details) {
				const cookie = details.responseHeaders.find(obj => obj.name === 'Set-Cookie').value;
				const token = StocksAPI.getCookieValue(cookie, 'csrftoken');
				if (!token) {
					throw new Error('Token not found!');
				}
				localStorage.setItem('tokenST', token);
				const tokenExpires = StocksAPI.getCookieValue(cookie, 'expires');
				StocksAPI.getAPIkey();
			},
			{ urls: ['https://www.alphavantage.co/support/*'] }, ['responseHeaders', 'extraHeaders']
		);
	}

	static getAPIkey() {
		chrome.identity.getProfileUserInfo(info => {
			const formData = new FormData();
			formData.append('email_text', info.email);
			const requestOptions = { method: 'POST', body: formData };
			fetch('https://www.alphavantage.co/create_post/', requestOptions)
				.then(response => response.text())
				.then(result => {
					try {
						if (result && JSON.parse(result).text) {
							const key = JSON.parse(result).text.match(/[A-Z0-9]{16}/g);
							if (!key) throw new Error('Key not found!');
							localStorage.setItem('keyST', key);
						} else {
							throw new Error('Key not found!');
						}
						// {"text": "It seems that you are already a registered user. As a reminder, your API key is: 2PQ5ABZ1TD6ORY67. Thank you!", "result": "Create post successful!"}
						// {"text": "Welcome to Alpha Vantage! Here is your API key: 9TRYH6RB6JXW9DJW. Please record this API key for future access to Alpha Vantage.", "result": "Create post successful!"}
					} catch (error) {
						throw error;
					}
				})
				.catch(error => console.log('error', error));
		});
	}

	static changeHeader(details, name, value) {
		const index = details.requestHeaders.findIndex(obj => obj.name === name);
		if (index === -1) {
			details.requestHeaders.push({ name, value });
		}
		else {
			details.requestHeaders[index].value = value;
		}
	}

	static getCookieValue(cookie, name) {
		const b = cookie.match('(^|[^;]+)\\s*' + name + '\\s*=\\s*([^;]+)');
		return b ? b.pop() : '';
	}

	static TIME_SERIES_INTRADAY(key) {
		return fetch('https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=MSFT&interval=5min&outputsize=full&apikey=' + key)
			.then(response => response.text());
	}

}