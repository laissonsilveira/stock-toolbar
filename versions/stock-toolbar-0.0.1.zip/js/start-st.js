StocksAPI.addHandlers();
StocksAPI.init();