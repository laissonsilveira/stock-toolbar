const LOCAL_TYPE = 'local';
//eslint-disable-next-line
class StoragePB {

    static get PWD() {
        return 'passwordPB';
    }

    static get LICENSE() {
        return 'licensePB';
    }

    static get QTD_LOCKED() {
        return 'qtdLockedPB';
    }

	static get CURRENT_DATE() {
        return 'currentDatePB';
    }

    static get BLOCK_EXT_TABS() {
        return 'blockExtTabsPB';
    }

    static get SITES() {
        return 'sitesPB';
    }

    static get SYNC_TYPE() {
        return 'sync';
    }

    static addValue(key, value, arg = LOCAL_TYPE) {
        return new Promise((resolve, reject) => {
            if (!key) {
                reject('key is required');
            } else {
                const stg = {};
                stg[key] = value;
                chrome.storage[arg].set(stg, resolve);
            }
        });
    }

    static getValue(key, arg = LOCAL_TYPE) {
        return new Promise((resolve, reject) => {
            if (!key) return reject('key is required');
            chrome.storage[arg].get(key, result => resolve(result[key]));
        });
    }

    static removeValue(key, arg = LOCAL_TYPE) {
        return new Promise((resolve, reject) => {
            if (!key) return reject('key is required');
            chrome.storage[arg].remove(key, resolve);
        });
    }

}